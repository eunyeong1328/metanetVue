DROP TABLE MEMBER CASCADE CONSTRAINTS;
DROP TABLE RESUME CASCADE CONSTRAINTS;
DROP TABLE COMPANY CASCADE CONSTRAINTS;
DROP TABLE POST CASCADE CONSTRAINTS;
DROP TABLE CAREER CASCADE CONSTRAINTS;
DROP TABLE RE_PROCESS CASCADE CONSTRAINTS;
DROP TABLE CERTIFICATE CASCADE CONSTRAINTS;
DROP TABLE APPLY CASCADE CONSTRAINTS;
DROP TABLE LANGUAGE CASCADE CONSTRAINTS;
DROP TABLE AWARD CASCADE CONSTRAINTS;
DROP TABLE ACTIVITY CASCADE CONSTRAINTS;
DROP TABLE FAVORITE CASCADE CONSTRAINTS;
DROP TABLE ATTACH CASCADE CONSTRAINTS;
DROP TABLE CONTRACT CASCADE CONSTRAINTS;
DROP TABLE PAY CASCADE CONSTRAINTS;
DROP TABLE DOCUMENT CASCADE CONSTRAINTS;
DROP TABLE PERSONALITY CASCADE CONSTRAINTS;
DROP TABLE INTERVIEW CASCADE CONSTRAINTS;
DROP TABLE REVIEW CASCADE CONSTRAINTS;
DROP TABLE EDUCATION CASCADE CONSTRAINTS;
DROP TABLE AD CASCADE CONSTRAINTS;
DROP TABLE APP_PROCESS CASCADE CONSTRAINTS;


CREATE TABLE "MEMBER" (
	"mem_seq"	NUMBER		NOT NULL,
	"mem_id"	VARCHAR2(100)		NOT NULL,
	"mem_pw"	VARCHAR2(100)		NOT NULL,
	"mem_name"	VARCHAR2(20)		NOT NULL,
	"mem_birth"	DATE		NULL,
	"mem_phone"	VARCHAR2(255)		NOT NULL,
	"mem_add"	VARCHAR2(255)		NULL,
	"mem_email"	VARCHAR2(255)		NOT NULL
);

CREATE TABLE "RESUME" (
	"resume_seq"	NUMBER		NOT NULL,
	"resume_image"	VARCHAR2(255)		NOT NULL,
	"resume_title"	VARCHAR2(255)		NOT NULL,
	"resume_gender"	VARCHAR2(10)		NOT NULL,
	"resume_technology"	VARCHAR2(255)		NOT NULL,
	"resume_career"	VARCHAR2(10)		NOT NULL,
	"mem_seq"	NUMBER		NOT NULL,
	"resume_cv"	VARCHAR2(1000)		NOT NULL
);

CREATE TABLE "COMPANY" (
	"com_cno"	NUMBER		NOT NULL,
	"com_name"	VARCHAR2(10)		NOT NULL,
	"com_phone"	VARCHAR2(14)		NULL,
	"com_type"	VARCHAR2(10)		NOT NULL,
	"com_sector"	VARCHAR2(45)		NOT NULL,
	"com_add"	VARCHAR2(45)		NOT NULL,
	"com_rep"	VARCHAR2(10)		NULL,
	"com_pnum"	NUMBER		NULL
);

CREATE TABLE "POST" (
	"post_seq"	NUMBER		NOT NULL,
	"post_division"	VARCHAR2(30)		NOT NULL,
	"post_title"	VARCHAR2(30)		NOT NULL,
	"post_job"	VARCHAR2(50)		NOT NULL,
	"post_career"	VARCHAR2(50)		NOT NULL,
	"post_emptype"	VARCHAR2(50)		NOT NULL,
	"post_add"	VARCHAR2(50)		NOT NULL,
	"post_sdate"	DATE		NULL,
	"post_fdate"	DATE		NULL,
	"post_sal"	VARCHAR2(10)		NULL,
	"post_edu"	VARCHAR2(50)		NULL,
	"post_gender"	VARCHAR2(30)		NULL,
	"post_age"	VARCHAR2(30)		NULL,
	"post_how"	VARCHAR2(30)		NULL,
	"post_url"	VARCHAR2(100)		NULL,
	"com_cno"	NUMBER		NOT NULL,
	"mem_seq"	NUMBER		NOT NULL
);

CREATE TABLE "CAREER" (
	"career_seq"	NUMBER		NOT NULL,
	"career_Sdate"	DATE		NOT NULL,
	"career_Fdate"	DATE		NOT NULL,
	"career_total"	NUMBER		NOT NULL,
	"career_jobTitle"	VARCHAR2(100)		NOT NULL,
	"career_job"	VARCHAR2(150)		NOT NULL,
	"career_company"	VARCHAR2(500)		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "CERTIFICATE" (
	"c_seq"	NUMBER		NOT NULL,
	"c_name"	VARCHAR2(255)		NOT NULL,
	"c_issuer"	VARCHAR2(500)		NOT NULL,
	"c_date"	DATE		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "APPLY" (
	"apply_no"	NUMBER		NOT NULL,
	"apply_date"	DATE		NULL,
	"resume_seq"	NUMBER		NULL,
	"post_seq"	NUMBER		NULL
);

CREATE TABLE "LANGUAGE" (
	"lang_seq"	NUMBER		NOT NULL,
	"lang_type"	VARCHAR2(255)		NOT NULL,
	"lang_test"	VARCHAR2(255)		NOT NULL,
	"lang_score"	NUMBER		NOT NULL,
	"lang_grade"	NUMBER		NOT NULL,
	"lang_date"	DATE		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "AWARD" (
	"award_seq"	NUMBER		NOT NULL,
	"award_name"	VARCHAR2(500)		NOT NULL,
	"award_issuer"	VARCHAR2(500)		NOT NULL,
	"award_date"	DATE		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "ACTIVITY" (
	"act_seq"	NUMBER		NOT NULL,
	"act_division"	VARCHAR2(50)		NOT NULL,
	"act_issuer"	VARCHAR2(500)		NOT NULL,
	"act_sdate"	DATE		NOT NULL,
	"act_fdate"	DATE		NOT NULL,
	"act_content"	VARCHAR2(1000)		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "FAVORITE" (
	"fav_seq"	NUMBER		NOT NULL,
	"post_seq"	NUMBER		NULL,
	"mem_seq"	NUMBER		NOT NULL
);

CREATE TABLE "ATTACH" (
	"att_seq"	NUMBER		NOT NULL,
	"att_division"	VARCHAR2(500)		NOT NULL,
	"att_name"	VARCHAR2(500)		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "CONTRACT" (
	"contract_seq"	NUMBER		NOT NULL,
	"contract_date"	VARCHAR2(50)		NOT NULL,
	"contract_amount"	NUMBER		NOT NULL
);

CREATE TABLE "PAY" (
	"pay_no"	NUMBER		NOT NULL,
	"com_cno"	NUMBER		NULL,
	"contract_seq"	NUMBER		NOT NULL,
	"ad_seq"	NUMBER		NOT NULL
);

CREATE TABLE "DOCUMENT" (
	"doc_seq"	NUMBER		NOT NULL,
	"doc_deadline"	DATE		NOT NULL,
	"doc_result"	VARCHAR(255)		NULL
);

CREATE TABLE "PERSONALITY" (
	"perso_seq"	NUMBER		NOT NULL,
	"pers_deadline"	DATE		NULL,
	"pers_testtype"	VARCHAR2(50)		NOT NULL,
	"pers_result"	VARCHAR2(20)		NULL
);

CREATE TABLE "INTERVIEW" (
	"intrv_seq"	NUMBER		NOT NULL,
	"intrv_date"	DATE		NOT NULL,
	"intrv_time"	VARCHAR2(20)		NOT NULL,
	"intrv_place"	VARCHAR2(20)		NOT NULL,
	"intrv_category"	VARCHAR2(20)		NULL,
	"intrv_result"	VARCHAR2(20)		NULL
);

CREATE TABLE "REVIEW" (
	"re_no"	NUMBER		NOT NULL,
	"re_company"	VARCHAR2(100)		NOT NULL,
	"re_job"	VARCHAR2(100)		NOT NULL,
	"re_date"	DATE		NOT NULL,
	"re_pnum"	NUMBER		NOT NULL,
	"re_content"	VARCHAR2(200)		NOT NULL,
	"re_star"	VARCHAR2(20)		NOT NULL,
	"re_result"	VARCHAR2(10)		NOT NULL,
	"mem_seq"	NUMBER		NOT NULL
);

CREATE TABLE "EDUCATION" (
	"edu_seq"	NUMBER		NOT NULL,
	"edu_division"	VARCHAR2(500)		NOT NULL,
	"edu_sdate"	DATE		NOT NULL,
	"edu_fdate"	DATE		NOT NULL,
	"edu_name"	VARCHAR2(500)		NOT NULL,
	"edu_department"	VARCHAR2(500)		NOT NULL,
	"resume_seq"	NUMBER		NOT NULL
);

CREATE TABLE "AD" (
	"ad_seq"	NUMBER		NOT NULL,
	"ad_type"	VARCHAR2(100)		NOT NULL,
	"ad_amount"	NUMBER		NOT NULL
);

CREATE TABLE "RECRUIT" (
	"post_seq"	NUMBER		NOT NULL,
	"doc_seq"	NUMBER		NOT NULL,
	"perso_seq"	NUMBER		NOT NULL,
	"intrv_seq"	NUMBER		NOT NULL
);

ALTER TABLE "MEMBER" ADD CONSTRAINT "PK_MEMBER" PRIMARY KEY (
	"mem_seq"
);

ALTER TABLE "RESUME" ADD CONSTRAINT "PK_RESUME" PRIMARY KEY (
	"resume_seq"
);

ALTER TABLE "COMPANY" ADD CONSTRAINT "PK_COMPANY" PRIMARY KEY (
	"com_cno"
);

ALTER TABLE "POST" ADD CONSTRAINT "PK_POST" PRIMARY KEY (
	"post_seq"
);

ALTER TABLE "CAREER" ADD CONSTRAINT "PK_CAREER" PRIMARY KEY (
	"career_seq"
);

ALTER TABLE "CERTIFICATE" ADD CONSTRAINT "PK_CERTIFICATE" PRIMARY KEY (
	"c_seq"
);

ALTER TABLE "APPLY" ADD CONSTRAINT "PK_APPLY" PRIMARY KEY (
	"apply_no"
);

ALTER TABLE "LANGUAGE" ADD CONSTRAINT "PK_LANGUAGE" PRIMARY KEY (
	"lang_seq"
);

ALTER TABLE "AWARD" ADD CONSTRAINT "PK_AWARD" PRIMARY KEY (
	"award_seq"
);

ALTER TABLE "ACTIVITY" ADD CONSTRAINT "PK_ACTIVITY" PRIMARY KEY (
	"act_seq"
);

ALTER TABLE "FAVORITE" ADD CONSTRAINT "PK_FAVORITE" PRIMARY KEY (
	"fav_seq",
	"post_seq"
);

ALTER TABLE "ATTACH" ADD CONSTRAINT "PK_ATTACH" PRIMARY KEY (
	"att_seq"
);

ALTER TABLE "CONTRACT" ADD CONSTRAINT "PK_CONTRACT" PRIMARY KEY (
	"contract_seq"
);

ALTER TABLE "PAY" ADD CONSTRAINT "PK_PAY" PRIMARY KEY (
	"pay_no",
	"com_cno"
);

ALTER TABLE "DOCUMENT" ADD CONSTRAINT "PK_DOCUMENT" PRIMARY KEY (
	"doc_seq"
);

ALTER TABLE "PERSONALITY" ADD CONSTRAINT "PK_PERSONALITY" PRIMARY KEY (
	"perso_seq"
);

ALTER TABLE "INTERVIEW" ADD CONSTRAINT "PK_INTERVIEW" PRIMARY KEY (
	"intrv_seq"
);

ALTER TABLE "REVIEW" ADD CONSTRAINT "PK_REVIEW" PRIMARY KEY (
	"re_no"
);

ALTER TABLE "EDUCATION" ADD CONSTRAINT "PK_EDUCATION" PRIMARY KEY (
	"edu_seq"
);

ALTER TABLE "AD" ADD CONSTRAINT "PK_AD" PRIMARY KEY (
	"ad_seq"
);

ALTER TABLE "RECRUIT" ADD CONSTRAINT "PK_RECRUIT" PRIMARY KEY (
	"post_seq"
);

ALTER TABLE "RESUME" ADD CONSTRAINT "FK_MEMBER_TO_RESUME_1" FOREIGN KEY (
	"mem_seq"
)
REFERENCES "MEMBER" (
	"mem_seq"
) on delete cascade;

ALTER TABLE "POST" ADD CONSTRAINT "FK_COMPANY_TO_POST_1" FOREIGN KEY (
	"com_cno"
)
REFERENCES "COMPANY" (
	"com_cno"
);

ALTER TABLE "POST" ADD CONSTRAINT "FK_MEMBER_TO_POST_1" FOREIGN KEY (
	"mem_seq"
)
REFERENCES "MEMBER" (
	"mem_seq"
);

ALTER TABLE "CAREER" ADD CONSTRAINT "FK_RESUME_TO_CAREER_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "CERTIFICATE" ADD CONSTRAINT "FK_RESUME_TO_CERTIFICATE_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "APPLY" ADD CONSTRAINT "FK_RESUME_TO_APPLY_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
);

ALTER TABLE "APPLY" ADD CONSTRAINT "FK_POST_TO_APPLY_1" FOREIGN KEY (
	"post_seq"
)
REFERENCES "POST" (
	"post_seq"
) on delete cascade;

ALTER TABLE "LANGUAGE" ADD CONSTRAINT "FK_RESUME_TO_LANGUAGE_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "AWARD" ADD CONSTRAINT "FK_RESUME_TO_AWARD_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "ACTIVITY" ADD CONSTRAINT "FK_RESUME_TO_ACTIVITY_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "FAVORITE" ADD CONSTRAINT "FK_POST_TO_FAVORITE_1" FOREIGN KEY (
	"post_seq"
)
REFERENCES "POST" (
	"post_seq"
);

ALTER TABLE "FAVORITE" ADD CONSTRAINT "FK_MEMBER_TO_FAVORITE_1" FOREIGN KEY (
	"mem_seq"
)
REFERENCES "MEMBER" (
	"mem_seq"
);

ALTER TABLE "ATTACH" ADD CONSTRAINT "FK_RESUME_TO_ATTACH_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
) on delete cascade;

ALTER TABLE "PAY" ADD CONSTRAINT "FK_COMPANY_TO_PAY_1" FOREIGN KEY (
	"com_cno"
)
REFERENCES "COMPANY" (
	"com_cno"
);

ALTER TABLE "PAY" ADD CONSTRAINT "FK_CONTRACT_TO_PAY_1" FOREIGN KEY (
	"contract_seq"
)
REFERENCES "CONTRACT" (
	"contract_seq"
);

ALTER TABLE "PAY" ADD CONSTRAINT "FK_AD_TO_PAY_1" FOREIGN KEY (
	"ad_seq"
)
REFERENCES "AD" (
	"ad_seq"
);

ALTER TABLE "REVIEW" ADD CONSTRAINT "FK_MEMBER_TO_REVIEW_1" FOREIGN KEY (
	"mem_seq"
)
REFERENCES "MEMBER" (
	"mem_seq"
);

ALTER TABLE "EDUCATION" ADD CONSTRAINT "FK_RESUME_TO_EDUCATION_1" FOREIGN KEY (
	"resume_seq"
)
REFERENCES "RESUME" (
	"resume_seq"
);

ALTER TABLE "RECRUIT" ADD CONSTRAINT "FK_POST_TO_RECRUIT_1" FOREIGN KEY (
	"post_seq"
)
REFERENCES "POST" (
	"post_seq"
);

ALTER TABLE "RECRUIT" ADD CONSTRAINT "FK_DOCUMENT_TO_RECRUIT_1" FOREIGN KEY (
	"doc_seq"
)
REFERENCES "DOCUMENT" (
	"doc_seq"
);

ALTER TABLE "RECRUIT" ADD CONSTRAINT "FK_PERSONALITY_TO_RECRUIT_1" FOREIGN KEY (
	"perso_seq"
)
REFERENCES "PERSONALITY" (
	"perso_seq"
);

ALTER TABLE "RECRUIT" ADD CONSTRAINT "FK_INTERVIEW_TO_RECRUIT_1" FOREIGN KEY (
	"intrv_seq"
)
REFERENCES "INTERVIEW" (
	"intrv_seq"
);

ALTER TABLE "DOCUMENT" 
ADD CONSTRAINT ck_doc_result CHECK("doc_result" IN('�հ�','���հ�'));

ALTER TABLE "PERSONALITY" 
ADD CONSTRAINT ck_pers_result CHECK("pers_result" IN('�հ�','���հ�'));

ALTER TABLE "INTERVIEW" 
ADD CONSTRAINT ck_intrv_result CHECK("intrv_result" IN('�հ�','���հ�'));

ALTER TABLE "POST" 
ADD CONSTRAINT ck_post_gentder CHECK("post_gender" IN('��','��')); 

ALTER TABLE "POST" 
ADD CONSTRAINT ck_post_career CHECK("post_career" IN('����','���')); 

ALTER TABLE "POST" 
ADD CONSTRAINT ck_post_edu CHECK("post_edu" IN('����','�ʴ���','����','���п�')); 

ALTER TABLE "POST" 
ADD CONSTRAINT ck_post_emptype CHECK("post_emptype" IN('������','�����','����','�İ���')); 


alter table resume 
add constraint chk_resume check ("resume_gender" in('��','��'));

alter table resume 
add constraint chk_resume02 check ("resume_career" in('����','���')); 


--�з�
alter table career  
add constraint chk_career check ("career_jobTitle" in('����','���','�븮','����','����','����','�ӿ�'));


--����
alter table ATTACH
add constraint chk_file check ("att_division" in('�̷¼�','��Ʈ������','�ڱ�Ұ���'));

--����
alter table education
add constraint chk_education check ("edu_division" in('����','�ʴ���','����','���п�'));


--Ȱ��
alter table activity
add constraint chk_activity check ("act_division" in('����','���Ƹ�','�ڿ�����','�����̼�'));


-- ����
ALTER TABLE COMPANY
    ADD CONSTRAINT ck_company_type
    CHECK ("com_type" IN('�߼ұ��', '�߰߱��', '����'));


-- ������ �߰�
CREATE SEQUENCE att_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;

CREATE SEQUENCE edu_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;

CREATE SEQUENCE act_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;

CREATE SEQUENCE award_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;
  
CREATE SEQUENCE c_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;

CREATE SEQUENCE career_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;

CREATE SEQUENCE lang_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;
  
CREATE SEQUENCE resume_seq
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 10000
  MINVALUE 1
  NOCYCLE;
    
CREATE SEQUENCE "doc_seq"
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;
    
CREATE SEQUENCE "perso_seq"
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;
    
CREATE SEQUENCE "intrv_seq"
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;
    
CREATE SEQUENCE "post_seq"
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    MINVALUE 1
    NOCYCLE;
